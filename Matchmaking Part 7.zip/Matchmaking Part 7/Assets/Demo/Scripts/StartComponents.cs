using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Barebones;
using Barebones.MasterServer;

public class StartComponents : MonoBehaviour {

    public GameObject ClientController;
    public GameObject MasterServer;
    public GameObject ClientStates;

    public GUIConsole guiConsole;

    void Start()
    {
        bool anythingStarted = false;
        bool inEditor = false;

#if UNITY_EDITOR
        inEditor = true;
#endif
        if (inEditor)
        {
            StartMasterServer();
            //StartClient();
            anythingStarted = true;
        }

        if (Msf.Args.StartMaster)
        {
            StartMasterServer();
            anythingStarted = true;
        }

        if (Msf.Args.IsProvided("-client"))
        {
            StartClient();
            anythingStarted = true;
        }

        if (!anythingStarted)
        {
            Debug.Log(string.Format("supported args: -client {0} {1}", Msf.Args.Names.StartMaster, Msf.Args.Names.StartSpawner));
        }

    }

    private void StartClient()
    {
        guiConsole.Show = false;
        ClientStates.SetActive(true);
        ClientController.gameObject.SetActive(true);
    }

    private void StartMasterServer()
    {
        MasterServer.gameObject.SetActive(true);
        MasterServerBehaviour master = MasterServer.GetComponent<MasterServerBehaviour>();
        master.StartServer();
    }


}
