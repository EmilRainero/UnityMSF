﻿using UnityEngine.Networking;

namespace Barebones.Networking
{
    public class BNetworkReader : NetworkReader
    {
        
    }
}