using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Barebones.Logging;
using Barebones.MasterServer;
using Barebones.Networking;

public enum GameServerState
{
    Initial,
    ConnectingToMaster,
    ConnectedToMaster,
    FailedToConnectToMaster,
    Registering,
    Registered,
    FailedToRegister,
    WaitingForClients,
    GameStarted,
    GameEnded,
    DisconnectedFromMaster,
    Stop
};

public class GameServer : MonoBehaviour {

    public LogLevel LogLevel = LogLevel.All;
    public BmLogger Logger = Msf.Create.Logger(typeof(GameServer).Name);

    public GameObject ButtonUI;
    public Button[] Buttons;

    public float QuitDelay = 10;
    private float WaitingToConnectToMaster = 0f;

    private float ConnectToMasterTimeout = 10f;

    private GameServerState _clientState;
    public GameServerState GameServerState
    {
        get { return _clientState; }
        set
        {
            _clientState = value;
            ShowGameServerState();
        }
    }

    private string _status;
    public string Status
    {
        set
        {
            _status = value;
        }
        get { return _status; }
    }

    ColorBlock highlightedColorBlock;

    private void ShowGameServerState()
    {
        if ((int)this.GameServerState < Buttons.Length &&
             Buttons[(int)this.GameServerState] != null)
        {
            Buttons[(int)this.GameServerState].Select();
            Buttons[(int)this.GameServerState].colors = highlightedColorBlock;
        }
    }

    public void Awake()
    {
        Logger.LogLevel = LogLevel;

        ButtonUI.gameObject.SetActive(true);

        highlightedColorBlock = ColorBlock.defaultColorBlock;
        highlightedColorBlock.highlightedColor = new Color(135 / 255f, 206 / 255f, 250 / 255f);

        GoToState_Initial();
    }

    private IEnumerator backgroundEnumerator;

    private void StopBackgroundEnumerator()
    {
        if (backgroundEnumerator != null)
        {
            StopCoroutine(backgroundEnumerator);
            backgroundEnumerator = null;
        }
    }

    private void GoToState_Initial()
    {
        GameServerState = GameServerState.Initial;
        Status = string.Empty;

        StartCoroutine(CoroutineUtils.StartWaiting(WaitingToConnectToMaster,
            () => { GoToState_ConnectingToMaster(); },
            1f,
            (time) => { Status = string.Format("Waiting {0}s", time); }, false));
    }

    private void GoToState_ConnectingToMaster()
    {
        GameServerState = GameServerState.ConnectingToMaster;
        Status = string.Empty;

        // connect to the master server
        Msf.Connection.Connected += Connected;
        Msf.Connection.Disconnected += Disconnected;

        Logger.Info(string.Format("Connecting to master on {0}:{1}", Msf.Args.MasterIp, Msf.Args.MasterPort));

        backgroundEnumerator = CoroutineUtils.StartWaiting(ConnectToMasterTimeout,
            () => { GoToState_FailedToConnectToMaster("Timed out"); },
            1f,
            (time) => { Status = string.Format("Trying to connect {0}s", time); });
        StartCoroutine(backgroundEnumerator);

        Msf.Connection.Connect(Msf.Args.MasterIp, Msf.Args.MasterPort);
    }

    private void Disconnected()
    {
        Logger.Info("Dsconnected");
    }

    private void Connected()
    {
        GoToState_ConnectedToMaster();
    }

    private void GoToState_FailedToConnectToMaster(string message)
    {
        GameServerState = GameServerState.FailedToConnectToMaster;
        Status = message;

        Msf.Connection.Connected -= Connected;
        Msf.Connection.Disconnected -= Disconnected;

        StartCoroutine(CoroutineUtils.StartWaiting(QuitDelay, () => { GoToState_Stop(); }));
    }

    private void GoToState_Stop()
    {
        GameServerState = GameServerState.Stop;
        Status = string.Empty;

        Application.Quit();
    }

    private void GoToState_ConnectedToMaster()
    {
        StopBackgroundEnumerator();

        GameServerState = GameServerState.ConnectedToMaster;
        Status = string.Empty;
    }

    void OnGUI()
    {
        GUIStyle style = new GUIStyle();
        Rect rect = new Rect(2, 2, Screen.width, style.fontSize);
        style.fontSize = 14;
        style.alignment = TextAnchor.UpperLeft;
        style.normal.textColor = Color.white;
        string text = string.Format("[GameServer | {0}] {1}",
            GameServerState, Status);
        GUI.Label(rect, text, style);
    }
}
