using Barebones.Logging;
using Barebones.MasterServer;
using Barebones.Networking;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class CustomMatchmaker : ServerModuleBehaviour
{
    public LogLevel LogLevel = LogLevel.Info;
    public BmLogger Logger = Msf.Create.Logger(typeof(CustomMatchmaker).Name);

    public int PlayersPerMatch = 1;
    public float PollFrequency = 2f;

    public event Action<int> WaitingPlayersChanged;
    public event Action<int> GamesUnderwayChanged;
    public event Action<int> GamesPlayedChanged;

    protected Dictionary<string, MatchmakerPlayer> playersWaiting;

    private IServer server;

    private int gamesPlayed;
    public int GamesPlayed
    {
        get
        {
            return gamesPlayed;
        }
        set
        {
            gamesPlayed = value;
            if (GamesPlayedChanged != null)
                GamesPlayedChanged.Invoke(gamesPlayed);
        }
    }


    public override void Initialize(IServer server)
    {
        base.Initialize(server);
        this.server = server;

        Logger.LogLevel = LogLevel;

        playersWaiting = new Dictionary<string, MatchmakerPlayer>();

        GamesPlayed = 0;

        this.server.SetHandler((short)CustomOpCodes.requestStartGame, RequestStartGame);

        StartCoroutine(MatchmakerCoroutine());
    }

    private void RequestStartGame(IIncommingMessage message)
    {
        int peerId = message.Peer.Id;
        var peer = Server.GetPeer(peerId);

        if (peer == null)
        {
            message.Respond("Peer with a given ID is not in the game", ResponseStatus.Error);
            return;
        }

        var account = peer.GetExtension<IUserExtension>();

        if (account == null)
        {
            message.Respond("Peer has not been authenticated", ResponseStatus.Failed);
            return;
        }

        AddMatchmakerPlayer(new MatchmakerPlayer(account.Username, message.Peer, Time.time));

        message.Respond("Ok", ResponseStatus.Success);
    }

    protected IEnumerator MatchmakerCoroutine()
    {
        while (true)
        {
            yield return new WaitForSeconds(PollFrequency);

            TryToStartAMatch();
        }
    }

    private bool TryToStartAMatch()
    {
        Logger.Info("Matchmaker " + playersWaiting.Count);

        if (playersWaiting.Count < PlayersPerMatch)
        {
            return false;
        }

        List<MatchmakerPlayer> usersInMatch = new List<MatchmakerPlayer>();

        int numberPlayers = 0;
        lock (playersWaiting)
        {
            while (true)
            {
                string user = playersWaiting.Keys.First();
                MatchmakerPlayer player = playersWaiting[user];
                RemoveMatchmakerPlayer(user);
                usersInMatch.Add(player);
                numberPlayers++;
                if (numberPlayers >= PlayersPerMatch)
                    break;
            }
        }

        StartMatch(usersInMatch);

        return true;
    }

    public void RemoveMatchmakerPlayer(string username)
    {
        bool removed = false;
        lock (playersWaiting)
        {
            if (playersWaiting.ContainsKey(username))
            {
                playersWaiting.Remove(username);
                removed = true;
            }
        }
        if (removed && WaitingPlayersChanged != null)
            WaitingPlayersChanged.Invoke(playersWaiting.Count);
    }

    public void AddMatchmakerPlayer(MatchmakerPlayer player)
    {
        bool added = false;
        lock (playersWaiting)
        {
            if (!playersWaiting.ContainsKey(player.Username))
            {
                playersWaiting.Add(player.Username, player);
                added = true;
            }
        }
        if (added && WaitingPlayersChanged != null)
            WaitingPlayersChanged.Invoke(playersWaiting.Count);
    }

    private bool StartMatch(List<MatchmakerPlayer> usersInMatch)
    {
        bool result;

        Match match = new Match(0, usersInMatch);
        NotifyClientsAndStartMatch(match);
        result = true;

        if (result == false)
        {
            ReturnPlayersToMatchmaker(usersInMatch);
        }

        return result;
    }

    private void ReturnPlayersToMatchmaker(List<MatchmakerPlayer> usersInMatch)
    {
        foreach (MatchmakerPlayer player in usersInMatch)
        {
            AddMatchmakerPlayer(player);
        }
    }

    private void NotifyClientsAndStartMatch(Match match)
    {
        var msg = Msf.Create.Message(
            (short)CustomOpCodes.gameServerMatchDetails,
            new GameServerMatchDetailsPacket()
            {
                SpawnId = match.SpawnId,
                MachineId = match.MachineId,
                AssignedPort = match.AssignedPort,
                SpawnCode = match.SpawnCode,
                GameSecondaryPort = match.GameSecondaryPort
            });

        foreach (var player in match.Players)
        {
            player.Peer.SendMessage(msg);
        }
    }

}

