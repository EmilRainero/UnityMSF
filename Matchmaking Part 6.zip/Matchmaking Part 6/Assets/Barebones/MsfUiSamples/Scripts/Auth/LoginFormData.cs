﻿namespace Barebones.MasterServer
{
    public class LoginFormData
    {
        public string Password;
        public string Username;
    }
}