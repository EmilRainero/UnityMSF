﻿
public class WorldDemoOpCodes
{
    // This request is sent from game server to master
    public const int TeleportRequest = 100;

    public const int EnterWorldRequest = 101;
    public const int GetCurrentZoneAccess = 102;
}
