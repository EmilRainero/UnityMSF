﻿using UnityEngine.Networking;

namespace Barebones.Networking
{
    public class BNetworkWriter : NetworkWriter
    {
        
    }
}