using Barebones.MasterServer;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MSFClientController : MonoBehaviour {

    public string ServerIp = "127.0.0.1";
    public int ServerPort = 5000;
    public ClientController controller;

    // timeouts and waits
    private float ConnectToMasterTimeout = 10f;
    private float LogInTimeout = 5f;

    private float WaitingToConnectToMaster = 1f;

    void Start()
    {
        UnityEngine.Random.InitState((int)(System.DateTime.Now.Ticks % 10000));

        GoToState_Initial();
    }

    private void GoToState_Initial()
    {
        controller.ClientState = ClientState.Initial;
        controller.Status = string.Empty;

        StartCoroutine(CoroutineUtils.StartWaiting(WaitingToConnectToMaster,
            () => { GoToState_ConnectingToMaster(); },
            1f,
            (time) => { controller.Status = string.Format("Waiting {0}s", time); }, false));
    }

    private IEnumerator backgroundEnumerator;

    private void StopBackgroundEnumerator()
    {
        if (backgroundEnumerator != null)
        {
            StopCoroutine(backgroundEnumerator);
            backgroundEnumerator = null;
        }
    }

    private void GoToState_ConnectingToMaster()
    {
        controller.ClientState = ClientState.ConnectingToMaster;

        backgroundEnumerator = CoroutineUtils.StartWaiting(ConnectToMasterTimeout,
                () => { GoToState_FailedToConnectToMaster("Timed out"); },
                1f,
                (time) => { controller.Status = string.Format("\"{0}:{1}\" {2}s", ServerIp, ServerPort, time); });
        StartCoroutine(backgroundEnumerator);

        Msf.Connection.Connected += OnConnected;
        Msf.Connection.Connect(ServerIp, ServerPort);
    }

    private void OnConnected()
    {
        GoToState_ConnectedToMaster();
    }

    private void GoToState_FailedToConnectToMaster(string error)
    {
        controller.ClientState = ClientState.FailedToConnectToMaster;
        controller.Status = error;
        StartCoroutine(CoroutineUtils.StartWaiting(1f, () => { GoToState_Initial(); }));
    }

    private void GoToState_ConnectedToMaster()
    {
        StopBackgroundEnumerator();

        controller.ClientState = ClientState.ConnectedToMaster;
        controller.Status = string.Format("at \"{0}:{1}\"", ServerIp, ServerPort);

        StartCoroutine(CoroutineUtils.StartWaiting(1f,
            () => { GoToState_LoggingIn(); }));
    }

    private void GoToState_LoggingIn()
    {
        controller.ClientState = ClientState.LoggingIn;
        controller.Status = string.Empty;

        backgroundEnumerator = CoroutineUtils.StartWaiting(LogInTimeout,
            () => { GoToState_FailedToLogIn("Timed out"); },
            1f,
            (time) => {
                controller.Status =
                    string.Format("Trying to log in {0}s", time);
            });
        StartCoroutine(backgroundEnumerator);

        Msf.Client.Auth.LogInAsGuest((successful, loginError) =>
        {
            if (successful == null)
            {
                GoToState_FailedToLogIn(loginError);
            }
            else
            {
                GoToState_LoggedIn(Msf.Client.Auth.AccountInfo.Username);
            }
        });
    }

    private void GoToState_LoggedIn(string username)
    {
        StopBackgroundEnumerator();

        controller.ClientState = ClientState.LoggedIn;
        controller.Status = string.Format("Logged in: {0}", username);

        StartCoroutine(CoroutineUtils.StartWaiting(3f,
            () => { GoToState_BetweenGames(); }));
    }

    private void GoToState_FailedToLogIn(string loginError)
    {
        controller.ClientState = ClientState.FailedToLogIn;
        controller.Status = loginError;

        StartCoroutine(CoroutineUtils.StartWaiting(3f,
            () => { GoToState_LoggingIn(); }));
    }

    private void GoToState_BetweenGames()
    {
        controller.ClientState = ClientState.BetweenGames;
        controller.Status = string.Empty;
    }


}
