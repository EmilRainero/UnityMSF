﻿namespace Barebones.Networking
{
    public enum DeliveryMethod
    {
        Unreliable,
        Reliable,
        ReliableSequenced
    }
}