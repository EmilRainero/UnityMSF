﻿namespace Barebones.MasterServer
{
    public class PasswordChangeData
    {
        public string Email;
        public string Code;
        public string NewPassword;
    }
}