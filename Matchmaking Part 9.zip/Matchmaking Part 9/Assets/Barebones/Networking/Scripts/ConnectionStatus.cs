﻿namespace Barebones.Networking
{
    public enum ConnectionStatus
    {
        None,
        Connecting,
        Connected,
        Disconnected
    }
}